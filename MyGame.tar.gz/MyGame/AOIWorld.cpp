#include "AOIWorld.h"

list<Player*> AOIWorld::GetSrdPlayers(Player* _Player)
{
	list<Player*>ret;
	//�����������
	int grid_id = (_Player->GetX() - this->x_begin) / this->x_width + (_Player->GetY() - this->y_begin) / y_width * x_count;
   


	//���㵱ǰ�����������������
	int x_index = grid_id % x_count;
	int y_index = grid_id / y_count;

	//�жϾ������ ȡ����Χ����������
	//���Ϸ�
	if (x_index > 0 && y_index > 0)
	{
		list<Player*>& cur_list = m_grids[grid_id - 1 - x_count].m_players;
		ret.insert(ret.begin(), cur_list.begin(), cur_list.end());
	}
	//���Ϸ�
	if (y_index > 0)
	{
		list<Player*>& cur_list = m_grids[grid_id - x_count].m_players;
		ret.insert(ret.begin(), cur_list.begin(), cur_list.end());
	}
	//���Ϸ�
	if (x_index < x_count - 1 && y_index>0)
	{
		list<Player*>& cur_list = m_grids[grid_id + 1 - x_count].m_players;
		ret.insert(ret.begin(), cur_list.begin(), cur_list.end());
	}
	//��
	if (x_index>0)
	{
		list<Player*>& cur_list = m_grids[grid_id - 1].m_players;
		ret.insert(ret.begin(), cur_list.begin(), cur_list.end());
	}
	//�Լ�
	list<Player*>& cur_list = m_grids[grid_id].m_players;
	ret.insert(ret.begin(), cur_list.begin(), cur_list.end());
	//�ҷ�
	if (x_index < x_count - 1)
	{
		list<Player*>& cur_list = m_grids[grid_id + 1].m_players;
		ret.insert(ret.begin(), cur_list.begin(), cur_list.end());
	}
	//���·�
	if (x_index > 0 && y_index < y_count - 1)
	{
		list<Player*>& cur_list = m_grids[grid_id - 1 + x_count].m_players;
		ret.insert(ret.begin(), cur_list.begin(), cur_list.end());
	}
	//�·�
	if (y_index < y_count - 1)
	{
		list<Player*>& cur_list = m_grids[grid_id + 1].m_players;
		ret.insert(ret.begin(), cur_list.begin(), cur_list.end());
	}

	//���·�
	if (x_index < x_count - 1 && y_index < y_count - 1)
	{
		list<Player*>& cur_list = m_grids[grid_id + 1 + x_count].m_players;
		ret.insert(ret.begin(), cur_list.begin(), cur_list.end());
	}

	return ret;
}

bool AOIWorld::AddPlayer(Player* _player)
{
	//x���������
	//������=(x-x.begin)/x.width + (y-.begin)/y.width*x.count

	int grid_id = (_player->GetX() - x_begin) / x_width + (_player->GetY() - y_begin) / y_width * x_count;

	//���ӵ�������
	m_grids[grid_id].m_players.push_back(_player);

	return true;
}

void AOIWorld::DelPlayer(Player* _player)
{
	int grid_id = (_player->GetX() - x_begin) / x_width + (_player->GetY() - y_begin) / y_width * x_count;
	m_grids[grid_id].m_players.remove(_player);
}

AOIWorld::AOIWorld(int x_begin, int x_end, int y_begin, int y_end, int x_count, int y_count) :
	x_begin(x_begin), x_end(x_end), y_begin(y_begin), y_end(y_end), x_count(x_count), y_count(y_count)
{
	//x��������� = (x.end - x.begin)/x���������� y����ͬ
	x_width = (x_end - x_begin) / x_count;
	y_width = (y_end - y_begin) / y_count;

	//�����������
	for (int i = 0; i < x_count * y_count; i++)
	{
		Grid temp;
		m_grids.push_back(temp);
	}





}

AOIWorld::~AOIWorld()
{
}
