#pragma once
#include<zinx.h>
#include"AOIWorld.h"
#include"msg.pb.h"
#include"ZinxTimer.h"
#include"RandomName.h"
#include<hiredis/hiredis.h>
class GameProtocol;
class GameMsg;
class GameRole :
    public Irole,public Player
{
    float x = 0;
    float y = 0;
    float z = 0;
    float v = 0;

    int iPid = 0;
    std::string szName;

    GameMsg* CreateIDNameLogin();
    GameMsg* CreateSrdPlayers();
    GameMsg* CreateSelfPosition();
    GameMsg* CreateIDNameLogoff();
    GameMsg* CreateTalkBroadCast(std::string _content);
    GameMsg* CreateNewPositionBroadCast(pb::Position* NewPos);
    //���������ı���Ϣ
    void ProcTalkMsg(std::string _content);

    //��������ƶ�����Ϣ
    void ProcMoveMsg(float _x, float _y, float _z, float _v);
    //��Ұ����
    void ViewAppear(GameRole* _pRole);
    //��Ұ��ʧ
    void ViewLost(GameRole* _pRole);
public:
    GameRole();
    ~GameRole();

    GameProtocol* m_protocol = NULL;
    // ͨ�� Irole �̳�
    bool Init() override;
    UserData* ProcMsg(UserData& _poUserData) override;
    void Fini() override;

    // ͨ�� Player �̳�
    int GetX() override;

    int GetY() override;

 

};

